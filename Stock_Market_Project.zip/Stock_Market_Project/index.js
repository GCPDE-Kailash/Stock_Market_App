const express = require('express');
const app = express();
const PORT = process.env.PORT || 5000;
const exphbs = require('express-handlebars');
const path = require('path');
const request = require('request');

// API Key for News API  pk_062031d20883444f9ea74e2610fe2011
// Create call  API function
function call_api(finsishedAPI) {
    request('https://cloud.iexapis.com/stable/stock/fb/quota?tocken=pk_062031d20883444f9ea74e2610fe2011',{json:true} , (err, res, body) => {
    if (err) { return console.log(err); }
    if (res.statusCode === 200) {
        // console.log(body);
        finsishedAPI(body);
    };
});
    
}
// Set Handlebars Middleware
app.engine('handlebars', exphbs.engine());
app.set('view engine', 'handlebars');
// Set handlebars routes
const otherstuff = 'Hello ! this Stuff part from index.js';
app.get('/', (req, res) => {
    // const api = call_api();
    call_api(function(doneAPI){
        res.render('home', {stock: doneAPI });
    });
});
// Create about page route 
app.get('/about.html', (req, res) => {
    res.render('about')});
// set static folder
app.use(express.static(path.join(__dirname, 'public')));
app.listen(PORT, () => {
    console.log('Server is listening on port: ', PORT);
})