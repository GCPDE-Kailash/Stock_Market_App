-> Requirements for Stock-Market Project

1- text editor- VS Code
2 -terminal command - VS Code
3- Node JS

-> in command-
----   'npm init -y' (it will install package.json)
for run the code, use ---'node fileName.js' static(only one time run)

-> Install Express JS and set PORT
   ---'npm install express --save'
-> Create 1st web page in public folder   
-> Setup Nodemon  ---'npm install -D nodemon'  D for development
    open package.json and remove test: part and add start and dev with index js file html file. 

    After that we can run our program with ---'npm run dev' ( will run continuous) 

    SO Far we did for Static system, Now we will make this Dynamic

 -> Install express Handlebars
    ---'npm install express --handlebars' 
        follow this - https://www.npmjs.com/package/express-handlebars  for creating folder home.handlebars and sub folder layout main.handlebars

        -> Handlebars Pages
        run this command ---'npm install --save express-handlebars'
        ## I was getting error- app.engine('handlebars', exphbs());
                                TypeError: exphbs is not a function

         ## Solution- I used exphbs()-> exphbs.engine()                  

         ## Pass varibale to Handlebars-
             
-> Version Control with Git.
    git config --global user.name "Your Name"
    git config --global user.email "you@youraddress.com"
    git config --global push.default matching
    git config --global alias.co checkout
    git init
    git add .
    git commit -m "first commit"
    git remote add origin  --repo_link
    git pull origin master
    git push -u origin master